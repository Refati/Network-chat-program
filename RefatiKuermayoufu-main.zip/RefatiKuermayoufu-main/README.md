## Project

### Network chat program

My project is to implement a network chat program where users can send messages to each other on the LAN. The program includes a server side and a client-side, wherein the server side is responsible for receiving and forwarding the information sent by the client side. At the beginning, the client cannot select a specific person to chat with, only on public channels. After the GUI of the client is implemented, the client can enter the IP address of the server and its own account password to realize the private chat function. If time permits, the online file transfer function will be added. Since I don't have my own fixed IP and server, this program can only run on the same LAN. You need a computer to open the server and tell others the IP address of the server, which will be printed in the console after the server program starts. The graphical interface implementation will be developed using JavaFX. The server will use multiple threads for processing, and the information transmission between the user and the server will use TCP protocol instead of UDP to ensure the correct information. This program is useful for teams with high information security requirements because no extranet is involved, and all information transfers take place locally.

 
