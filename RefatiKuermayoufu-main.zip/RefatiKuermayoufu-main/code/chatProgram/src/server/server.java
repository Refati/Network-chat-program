package server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * The main class of the server
 */
public class server {

    /**
     * connect num
     */
    public static int counter=0;
    /**
     * all User
      */
    public static ArrayList<Socket> allUser;//store allUser
    /**
     * server socket
     */
    public static ServerSocket server;
    /**
     * user data array
     */
    public static ArrayList<UserData> allUserData;
    /**
     * connect user data
     */
    public static ArrayList<UserData> connectedUser;
    /**
     * input scanner
     */
    public static Scanner scanner;
    /**
     * statr server
     * @param args Command line argument
     * @throws IOException if an I/O error occurs
     */
    public static void main(String[] args) throws IOException {
        new server().run();
    }

    /**
     * server construct method
     * @throws IOException if an I/O error occurs when waiting for a connection.
     */
    public server() throws IOException {
        InetAddress address=InetAddress.getLocalHost();
        server=new ServerSocket(2000,300,address);
        System.out.println("The server is successfully started.IP: "+server.getInetAddress().getHostAddress()+
                "  port:2000");
        allUser=new ArrayList<Socket>();
        allUserData=new ArrayList<UserData>();
        connectedUser=new ArrayList<UserData>();
        scanner=new Scanner(System.in);
        readUserData();

    }
    /**
     * start server,start the listening connection.
     * In addition, the local area IP address of the server and
     * the number of connected users are displayed.
     * @throws IOException if an I/O error occurs when waiting for a connection.
     */
    public void run() throws IOException {
        new ServerManage().start();
        while (true){//Keep the server running forever
            Socket incoming=server.accept();
            counter++;

            allUser.add(incoming);
            Handle handle=new Handle(incoming);
            handle.start();
        }
    }

    /**
     * Sending a user's message to other users
     * @param userData socket for a specific user
     * @param message The message to send
     * @throws IOException if an I/O error occurs
     */
    public static void sendMessage(UserData userData,String message) throws IOException {
        for(UserData user:connectedUser)//Traverse the connected user
        {
            if(!user.equals(userData)){
                OutputStream outputStream=user.getSocket().getOutputStream();
                outputStream.write((userData.getName()+" : "+message).getBytes());
                outputStream.flush();
            }
        }
    }
/**
 * Send information to a specific user.
 * @param userData sender
 * @param name recipient
 * @param message message
 * @throws IOException if an I/O error occurs
 */
    public static void sendPrivateMessage(UserData userData,String name,String message)
    throws IOException 
    {
        for(UserData user:connectedUser)//Traverse the connected user
        {
            if(user.getName().equals(name))
            {
                OutputStream outputStream=user.getSocket().getOutputStream();
                outputStream.write((userData.getName()+" : "+message).getBytes());
                outputStream.flush();
                break;
            }
        }

    }

    /**
     * Returns the IP address of the server
     * @return Returns the IP address of the server
     */
    public String getServerIp()
    {
        return server.getInetAddress().getHostAddress().toString();
    }
/**
 * Reads user data from a file
 * @throws IOException if an I/O error occurs
 */
    public void readUserData() throws IOException
    {
        File data=new File("UserData");
        BufferedReader bufferedReader=new BufferedReader(new FileReader(data));
        String str=null;
        while((str=bufferedReader.readLine())!=null)
        {
            String[] strs=str.split(" ");
            allUserData.add(new UserData(strs[0], strs[1]));
        }
        bufferedReader.close();
    }
/**
 * Update user data to a file
 * @throws IOException if an I/O error occurs
 */
    public static void writeUserData() throws IOException
    {
        File newFile=new File("UserData(temp)");
        BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(newFile));
        for(int i=0;i<allUserData.size();i++)
        {
            bufferedWriter.write(allUserData.get(i).getAccount()+" "+allUserData.get(i).getPassword()+" \n");
        }
        bufferedWriter.flush();
        bufferedWriter.close();
        File oldFile=new File("UserData");
        oldFile.delete();
        File newName=new File("UserData");
        if(!newName.exists())
        {
            newFile.renameTo(newName);
        }

    }
}
