package server;

import java.io.IOException;

/**
 * This thread is used to process the relevant transactions of the server.
 */
public class ServerManage extends Thread{
/**
 * run thread
 */
    @Override
    public void run() {
        boolean flag=true;
        while(flag)
        {
            System.out.println("Select the action you want to perform.");
            System.out.println("1.print all user.");
            System.out.println("2.print all connected user.");
            System.out.println("3.add a user.");
            System.out.println("4.remove a uesr.");
            System.out.println("5.exit.");
            String choice=server.scanner.next();
            try{
                int num=Integer.parseInt(choice);
                if(5<num||num<1){
                    System.out.println("Please enter the correct number.");
                    continue;
                }
                switch(num)
                {
                    case 1:
                        printAllUser();
                        break;
                    case 2:
                        printAllConnectedUser();
                        break;
                    case 3:
                        addUser();
                        break;
                    case 4:
                        removeUser();
                        break;
                    case 5:
                        flag=false;
                }

            }catch (NumberFormatException numberFormatException)
            {
                System.out.println("Please enter the correct number.");
            }

        }
        
    }
    /**
     * Prints all users that exist in the database
     */
    public void printAllUser()
    {
        System.out.println("All user data: "+server.allUserData.size());
        for(int i=0;i<server.allUserData.size();i++)
        {
            System.out.println(i+1+": "+"account:"+server.allUserData.get(i).getAccount()+
            " password:"+server.allUserData.get(i).getPassword());
        }
    }
    /**
     * Prints all connected users
     */
    public void printAllConnectedUser()
    {
        System.out.println("All connected users: "+server.connectedUser.size());
        for(int i=0;i<server.connectedUser.size();i++)
        {
            System.out.println(i+1+": "+"account:"+server.connectedUser.get(i).getAccount()+
            " password:"+server.connectedUser.get(i).getPassword());
        }
    }
/**
 * Add a user to the server
 */
    public void addUser()
    {
        boolean flag=false;
        while(flag==false)
        {
            System.out.println("Please enter the account you want to add");
            String account=server.scanner.next();
            int i=0;
            for(;i<server.allUserData.size();i++)
            {
                if(account.equals(server.allUserData.get(i).getAccount()))
                {
                    System.out.println("The account already exists");
                    break;
                }
            }
            if(i!=server.allUserData.size()){
                continue;
            }
            System.out.println("Please enter the passward");
            String passward=server.scanner.next();
            server.allUserData.add(new UserData(account, passward));
            flag=true;
        }
        try{
            server.writeUserData();
            System.out.println("add success!");
        }catch(IOException ioException){
            System.err.println("add failed");
        }
    }
    /**
     * Delete a user from the database
     */
    public void removeUser()
    {
        boolean flag=false;
        while(flag==false)
        {
            System.out.println("Please enter the account you want to remove(q-cancel)");
            String account=server.scanner.next();
            if(account.equals("q"))
            {
                return;
            }
            for(int i=0;i<server.allUserData.size();i++)
            {
                if(account.equals(server.allUserData.get(i).getAccount()))
                {
                    server.allUserData.remove(i);
                    flag=true;
                }
            }
            if(flag)
            {
                try{
                    server.writeUserData();
                    System.out.println("remove success");
                }catch(IOException ioException){
                    System.err.println("remove failed");
                }
            }else{
                System.out.println("No such user");
            }            
        }
        
        
    }
    
}
