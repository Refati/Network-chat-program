package server;
/**
 * Store user data, including user name, password, and socket.
 */

import java.net.Socket;

/**
 * User data class
 */
public class UserData {

    private String name;
    private String account;
    private String password;
    private Socket socket;
    /**
     * construct
     * @param account user account
     * @param password user password
     */
    public UserData(String account, String password) {
        this.account = account;
        this.password = password;
    }

    /**
     * return user data
     */
    @Override
    public String toString() {
        return "UserData [name=" + name + ", account=" + account + ", password=" + password + "]";
    }

    /**
     * return true if two user equal
     */
    @Override
    public boolean equals(Object obj) {
        UserData us=(UserData)obj;
        if(us.getAccount().equals(this.getAccount())&&
                us.getPassword().equals(this.getPassword()))
        {
            return true;
        }
        return false;
    }
    /**
     * return name
     * @return name
     */
    public String getName() {
        return name;
    }
    /**
     * return password
     * @return password
     */
    public String getPassword() {
        return password;
    }
    /**
     * return socket
     * @return socket
     */
    public Socket getSocket() {
        return socket;
    }
    /**
     * set name
     * @param name the user name
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * set password
     * @param password the user password
     */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * set socket 
     * @param socket the user socket
     */
    public void setSocket(Socket socket) {
        this.socket = socket;
    }
    /**
     * return account
     * @return account
     */
    public String getAccount() {
        return account;
    }

    
    
}
