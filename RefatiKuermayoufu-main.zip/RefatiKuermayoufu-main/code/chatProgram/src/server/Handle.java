package server;
import java.io.*;
import java.net.Socket;

/**
 * The server is multithreaded, with one user per thread,
 * and later uses thread pools for management and messaging.
 * Note:This class is not implemented complete
 */
public class Handle extends Thread{
    private Socket socket;
    private InputStream socketInput;
    private OutputStream outputStream;
    UserData userData;

    /**
     * Handles class constructors
     * @param socket Receive a socket that has been connected to the server
     */
    public Handle(Socket socket){
        this.socket=socket;
        try {
            socketInput=this.socket.getInputStream();
            outputStream=socket.getOutputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Receive a user message and forward the message to another user.
     */
    @Override
    public void run(){
        boolean loginSuccess=false;
        try {
            byte[] buffer=new byte[1024];
            while (!socket.isClosed()) {
                //receive message
                int len=socketInput.read(buffer);

                if (len!=-1) {
                    String message=new String(buffer,0,len);

                    if(loginSuccess==false&&message.startsWith("Login"))
                    {
                        String[] str=message.split(" ");
                        userData=new UserData(str[1], str[2]);
                        for(int i=0;i<server.allUserData.size();i++)
                        {
                            if(server.allUserData.get(i).equals(userData)&&!server.connectedUser.contains(userData))
                            {
                                outputStream.write("TRUE".getBytes());
                                loginSuccess=true;
                                userData.setName(str[3]);
                                userData.setSocket(socket);
                                server.connectedUser.add(userData);
                                //System.out.println(userData.toString());
                            }
                        }
                        if(loginSuccess==false)
                        {
                            outputStream.write("FALSE".getBytes());
                        }
                        continue;
                    }

                    if(message.equals("q")){
                        break;
                    }
                    if(message.startsWith("\\"))
                    {
                        String[] str=message.split(" ");
                        String name=str[0].substring(1);
                        server.sendPrivateMessage(userData, name, message.substring(str[0].length()));
                    }else{
                        server.sendMessage(userData,message);//send message to all
                    }
                    
                }
            }
        }catch(IOException ioException)
        {
            System.out.println("close");
        }finally {
            server.counter--;
            server.allUser.remove(socket);
            server.connectedUser.remove(userData);
        }

    }

}
