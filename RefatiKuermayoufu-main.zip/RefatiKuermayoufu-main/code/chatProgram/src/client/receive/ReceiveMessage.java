package client.receive;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
/**
 * receive message in the background,using multithreading.
 */
public class ReceiveMessage extends Thread{
    Socket socket;
/**
 * The parameterized constructor of this class
 * @param socket socket connection of client
 */
    public ReceiveMessage(Socket socket){
        this.socket=socket;
    }
    /**
     * Receives messages until the socket ends
     */
    @Override
    public void run()
    {
        try{
            InputStream inputStream=socket.getInputStream();
            byte[] buffer=new byte[1024];  
            while(!socket.isClosed())
            {
                
                try{
                    int len=inputStream.read(buffer);
                    if(len!=-1)
                    {
                        System.out.println(new String(buffer,0,len));//debug,check receive message
                    }
                }catch(SocketTimeoutException exception)//no news for now
                {
                    continue;
                }catch(SocketException exception)//socket close
                {
                    break;
                }

            }
        }catch(IOException ioException)
        {
            System.out.println(ioException.getMessage());
            return;
        }
    }
}

