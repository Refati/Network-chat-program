package client;
import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import client.receive.ReceiveMessage;
import java.net.SocketException;
import java.net.SocketTimeoutException;
/**
 * The client starts the main class
 * This class will serve as the main class of the client program,
 * and the entry to the client program will be on this class.
 * You are now able to connect to the server and receive user input.
 */
public class client {
    /**
     * Server IP Address
     */
    public String serverIP;
    /**
     * socket
     */
    public Socket socket;
    /**
     * running state
     */
    public boolean running;
    /**
     * input
     */
    public Scanner scanner;


    /**
     * Client program entry
     * connect to the server and receiver user input.
     * @throws IOException readAndsend() function
     * @param args main function param ,just is a normal form.
     */
    public static void main(String[] args) throws IOException {
        new client().run();
    }

    /**
     * construct method
     */
    public client(){
        running=true;
        scanner=new Scanner(System.in);
        connectServer();
    }

    /**
     * Start the client
     * @throws IOException readAndsend() function
     */
    public void run() throws IOException {
        login();
        readAndSend();
    }

    /**
     * start receive thread
     */
    public void startReceive(){
        ReceiveMessage receiveMessage=new ReceiveMessage(socket);
        receiveMessage.start();
    }

    /**
     * Read user input and receive messages from the server
     * @throws IOException if scanner is closed
     */
    public void readAndSend() throws IOException {
        OutputStream outputStream=socket.getOutputStream();
        startReceive();    //start receive
        while (true) {
            System.out.print("(q-quit)input>");
            String inputMesssage = scanner.nextLine();
            //send message to server
            outputStream.write(inputMesssage.getBytes());
            if (inputMesssage.equals("q")) {
                break;
            }
            
        }
        outputStream.close();
        scanner.close();
        closeConnect();
    }

    /**
     * Connect to the server over tcp
     */
    public void connectServer() {
        //read ip address
        System.out.println("Enter the IP address of the server you want to connect to");
        serverIP = scanner.nextLine();
        System.out.println(String.format("The IP address you entered is %s", serverIP));

        try {
            //Attempt to connect to the server
            System.out.println("start connect!");
            socket = new Socket(serverIP, 2000);
            socket.setSoTimeout(3000);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        System.out.println("connect success!!!");
        //Provide input terminals to the use
    }
    /**
     * User login interface,Handle the user login function
     * @return ture(if login success) false(if login fail)
     * @throws IOException if scanner is closed
     */
    public boolean login() throws IOException {
        OutputStream outputStream=socket.getOutputStream();
        InputStream inputStream=socket.getInputStream();
        while(!socket.isClosed())
        {
            //read user input
            System.out.println("Please enter the user account");

            String account = scanner.nextLine();
            System.out.println("Please enter the password");
            String password=scanner.nextLine();
            System.out.println("Please enter the name");
            String name=scanner.nextLine();
            try{
                outputStream.write(("Login "+account+" "+password+" "+name).getBytes());
                byte[] buffer=new byte[1024];
                int len=inputStream.read(buffer);
                String result=new String(buffer,0,len);
                if(result.equals("TRUE"))
                {
                    System.out.println("login success!");
                    break;
                }else{
                    System.out.println("Incorrect username password or the account is logged in, please re-enter.");
                }
            }catch(SocketTimeoutException exception)//no news for now
            {
                continue;
            }catch(SocketException exception)//socket close
            {
                return false;                
            }
            
        }
        return true;
    }
/**
 * Closing socket connection
 * @throws IOException   if an I/O error occurs when closing socket.
 */
    public void closeConnect() throws IOException{
        socket.close();   
    }
}
