package Test;
import org.junit.*;

import client.client;
import server.*;
import static org.junit.Assert.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import org.junit.Test;
import org.junit.Before;
/**
 * junit tests the connection between the client and the server.
 * don't need to 
 */
public class TestConnect2 {
    /**
     * server ip address
     */
    String serverIPAddress;
    /**
     * outputStream from stdout put
     */
    ByteArrayOutputStream outputStream;
    /**
     * my input
     */
    ByteArrayInputStream inputStream;

    /**
     * get the stdout stream
     */
    PrintStream printStream;
    /**
     * server instance
     */
    public static server server1;


    /**
     * initial variable
     * @throws IOException  if an I/O error occurs
     */
    @Before
    public void setUP() throws IOException {

        String input=serverIPAddress+"\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        outputStream=new ByteArrayOutputStream();
        printStream=new PrintStream(outputStream);
        System.setIn(inputStream);
        System.setOut(printStream);
        if(server1==null){
            server1=new server();
        }

        serverIPAddress= server.server.getInetAddress().getHostAddress();
    }

    /**
     * accept connection from client
     * @throws IOException if an I/O error occurs
     */
    public void addConnection() throws IOException {
        Socket incoming= server.server.accept();
        server.counter++;

        server.allUser.add(incoming);
        Handle handle=new Handle(incoming);
        handle.start();
    }


    /**
     * test send message
     * @throws IOException if an I/O error occurs
     */
    @Test
    public void testSendAllMessage() throws IOException {
        String input=serverIPAddress+"\n11111\n12344\na1\n22222\n12345\na2\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client1=new client();
        addConnection();
        client1.login();
        client1.startReceive();
        input=serverIPAddress+"\n11111\n12344\na1\n11111\n12345\na1\n"+"testMessage\nq\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client2=new client();
        addConnection();
        client2.login();
        UserData userData=new UserData("aaa","bbb");
        userData.setName("a3");
        server.sendPrivateMessage(userData,"a2","private");
        for(int i=0;i<1e6;) {i++;}
        assertTrue(outputStream.toString().contains("private"));
        client1.closeConnect();
        client2.closeConnect();

    }

    /**
     * release bind
     * @throws IOException if an I/O error occurs
     */
    @AfterClass
    public static void close() throws IOException {
        server.server.close();
    }

}
