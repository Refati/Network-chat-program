package Test;
import org.junit.*;

import client.client;
import server.*;
import static org.junit.Assert.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import org.junit.Test;
import org.junit.Before;
/**
 * junit tests the connection between the client and the server.
 * don't need to 
 */
public class TestConnect {
    /**
     * server ip address
     */
    String serverIPAddress;
    /**
     * outputStream from stdout put
     */
    ByteArrayOutputStream outputStream;
    /**
     * my input
     */
    ByteArrayInputStream inputStream;

    /**
     * get the stdout stream
     */
    PrintStream printStream;
    /**
     * server instance
     */
    public static server server1;


    /**
     * initial variable
     * @throws IOException  if an I/O error occurs
     */
    @Before
    public void setUP() throws IOException {

        String input=serverIPAddress+"\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        outputStream=new ByteArrayOutputStream();
        printStream=new PrintStream(outputStream);
        System.setIn(inputStream);
        System.setOut(printStream);
        if(server1==null){
            server1=new server();
        }

        serverIPAddress= server.server.getInetAddress().getHostAddress();
    }

    /**
     * accept connection from client
     * @throws IOException if an I/O error occurs
     */
    public void addConnection() throws IOException {
        Socket incoming= server.server.accept();
        server.counter++;

        server.allUser.add(incoming);
        Handle handle=new Handle(incoming);
        handle.start();
    }

    /**
     * test connection and login
     * @throws IOException if an I/O error occurs
     */
    @Test
    public void testConnectOne() throws IOException {
        String input=serverIPAddress+"\n11111\n12344\na1\n11111\n12345\na1\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client1=new client();
        addConnection();
        assertTrue(outputStream.toString().contains("connect success!!!"));
        client1.login();
        assertTrue(outputStream.toString().contains("login success!"));
        client1.closeConnect();
    }

    /**
     * test run method
     * @throws IOException if an I/O error occurs
     */
    @Test
    public void testRun() throws IOException {
        String input=serverIPAddress+"\n11111\n12344\na1\n22222\n12345\na1\n"+"hello\n\\a2 asasa\nq\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client1=new client();
        addConnection();
        client1.run();
        client1.closeConnect();
        assertTrue(outputStream.toString().contains("(q-quit)input>"));
    }
    /**
     * test userData
     */
    @Test
    public void testUserData(){
        UserData userData=new UserData("aaa","bbb");
        userData.setName("name");
        assertEquals("name",userData.getName());
        assertEquals("aaa",userData.getAccount());
        assertEquals("UserData [name=name, account=aaa, password=bbb]",userData.toString());
        assertNull(userData.getSocket());
        userData.setPassword("ccc");
        assertEquals("ccc",userData.getPassword());
    }

    /**
     * release bind
     * @throws IOException if an I/O error occurs
     */
    @AfterClass
    public static void close() throws IOException {
        server.server.close();
    }

}
