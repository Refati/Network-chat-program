package Test;

import client.client;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import server.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

import server.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * test send private message
 */
public class TestSendMessage {
    /**
     * server ip address
     */
    String serverIPAddress;
    /**
     * outputStream from stdout put
     */
    ByteArrayOutputStream outputStream;
    /**
     * my input
     */
    ByteArrayInputStream inputStream;

    /**
     * get the stdout stream
     */
    PrintStream printStream;
    /**
     * server instance
     */
    public static server server1;
    /**
     * Before you start running the test, start the server and replace the appropriate IP string
     * @throws IOException if an I/O error occurs
     */
    @Before
    public void setUP() throws IOException {
        String input=serverIPAddress+"\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        outputStream=new ByteArrayOutputStream();
        printStream=new PrintStream(outputStream);
        System.setIn(inputStream);
        System.setOut(printStream);
        if(server1==null){
            server1=new server();
        }
        serverIPAddress= server.server.getInetAddress().getHostAddress();
    }

    /**
     * add connection to server
     * @throws IOException if an I/O error occurs
     */
    public void addConnection() throws IOException {
        Socket incoming= server.server.accept();
        server.counter++;
        server.allUser.add(incoming);
        Handle handle=new Handle(incoming);
        handle.start();
    }

    /**
     * test login error and send message to all connected user
     * @throws IOException if an I/O error occurs
     */
    @Test
    public void testClientException() throws IOException {
        String input=serverIPAddress+"\n11111\n12344\na1\n22222\n12345\na2\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client1=new client();
        addConnection();
        client1.login();
        client1.startReceive();

        input=serverIPAddress+"\n11111\n12344\na1\n11111\n12345\na1\n"+"testMessage\nq\n";
        inputStream=new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);
        client client2=new client();
        addConnection();
        client2.login();
        client2.readAndSend();




        server.sendMessage(new UserData("aa","bb"),"test");
        for(int i=0;i<1e5;i++) {i++;}
        assertTrue(outputStream.toString().contains("test"));

        assertEquals(serverIPAddress,server1.getServerIp());
        client1.closeConnect();
        for(int i=0;i<1e5;i++){i++;}
        client2.closeConnect();


    }

    /**
     * release bind
     * @throws IOException if an I/O error occurs
     */
    @AfterClass
    public static void close() throws IOException {
        server.server.close();
    }


}
