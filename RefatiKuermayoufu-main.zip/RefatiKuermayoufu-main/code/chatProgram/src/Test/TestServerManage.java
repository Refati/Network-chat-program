package Test;


import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import server.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;


import static org.junit.Assert.assertTrue;

/**
 * test server manage
 */
public class TestServerManage {
    /**
     * outputStream from stdout put
     */
    ByteArrayOutputStream outputStream;
    /**
     * my input
     */
    ByteArrayInputStream inputStream;
    /**
     * get the stdout stream
     */
    PrintStream printStream;

    /**
     * initial variable
     */
    @Before
    public void setup() {
        outputStream=new ByteArrayOutputStream();
        printStream=new PrintStream(outputStream);
        System.setIn(inputStream);
        System.setOut(printStream);


    }

    /**
     * test all choice in server manage
     */
    @Test
    public void testPrint() throws IOException {
        inputStream=new ByteArrayInputStream("a\n0\n1\n2\n3\n11111\n55555\n11111\n4\nq\n4\n12313\n55555\n5\n".getBytes());
        System.setIn(inputStream);
        ServerManage serverManage=new ServerManage();
        server server1=new server();
        server1.getServerIp();
        server.scanner=new Scanner(System.in);
        server.connectedUser.add(new UserData("aaa","bbb"));
        serverManage.run();
        assertTrue(outputStream.toString().contains("11111"));
        assertTrue(outputStream.toString().contains("aaa"));
        assertTrue(outputStream.toString().contains("Please enter the correct number"));
        assertTrue(outputStream.toString().contains("add success!"));
        assertTrue(outputStream.toString().contains("remove success"));
    }
    /**
     * release bind
     * @throws IOException if an I/O error occurs
     */
    @AfterClass
    public static void close() throws IOException {
        server.server.close();
    }
}
